package com.cts.farmscheme.FarmSchemeManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmSchemeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
