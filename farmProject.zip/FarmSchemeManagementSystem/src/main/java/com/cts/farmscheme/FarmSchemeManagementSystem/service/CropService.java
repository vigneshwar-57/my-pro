package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Farmer;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.CropRepository;

@Service
public class CropService {
	
	    @Autowired
	    private CropRepository cropRepository;
	 
	    public Crop addCrop(Crop crop) {
	    	crop.setPlacedDate(LocalDateTime.now());
	    	
	        return cropRepository.save(crop);
	    }
	    public List<Crop> getAllCrops() {
	        return cropRepository.findAll();
	    }
	
	    public Crop getCropById(Long cropId) {
	        return cropRepository.findById(cropId)
	                .orElseThrow(() -> new RuntimeException("Crop not found with id: " + cropId));
	    }
	 
	    public Crop updateCrop(Long cropId, Crop cropDetails) {
	        Crop crop = cropRepository.findById(cropId).orElseThrow(() -> new RuntimeException("Crop not found with id: " + cropId));
	        if (cropDetails.getCropName() != null && !cropDetails.getCropName().isEmpty()) {
	            crop.setCropName(cropDetails.getCropName());
	        }
	        if (cropDetails.getCropType() != null && !cropDetails.getCropType().isEmpty()) {
	            crop.setCropType(cropDetails.getCropType());
	        }
	        if (cropDetails.getQuantity() != null) {
	            crop.setQuantity(cropDetails.getQuantity());
	        }
	        if (cropDetails.getPricePerUnit() != null) {
	            crop.setPricePerUnit(cropDetails.getPricePerUnit());
	        }
	        
	        return cropRepository.save(crop);
	    }
	 
	    public boolean deleteCrop(Long cropId) {
	        Crop crop = cropRepository.findById(cropId).orElseThrow(() -> new RuntimeException("Crop not found with id: " + cropId));
	        cropRepository.delete(crop);
	        return true;
	    }
	    public Optional<Crop> findCropById(Long id){
	    	return cropRepository.findById(id);
	    }
	 
		public List<Crop> findCropByCropName(String cropName) {
			
			return cropRepository.findByCropName(cropName);
		}
		
		
}
