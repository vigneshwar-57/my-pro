package com.cts.farmscheme.FarmSchemeManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bidder;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.BidderService;

@RestController
@RequestMapping("/bidders")
public class BidderController {

    @Autowired
    private BidderService bidderService;

    @PostMapping
    public Bidder addBidder(@RequestBody Bidder bidder) {
       return bidderService.addBidder(bidder);
    }

    @GetMapping
    public List<Bidder> getAllBidders() {
        return bidderService.getAllBidders();
    }

    @GetMapping("/{bidderId}")
    public Bidder getBidderById(@PathVariable Long bidderId) {
        return bidderService.getBidderById(bidderId);
    }

    @PutMapping("/{bidderId}")
    public Bidder updateBidder(@PathVariable Long bidderId, @RequestBody Bidder bidder) {
        Bidder existingBidder = bidderService.getBidderById(bidderId);
        existingBidder.setBidderName(bidder.getBidderName());
        existingBidder.setAadharNumber(bidder.getAadharNumber());
        existingBidder.setAccountNumber(bidder.getAccountNumber());
        existingBidder.setPassword(bidder.getPassword());
        existingBidder.setEmailId(bidder.getEmailId());
        existingBidder.setAddress(bidder.getAddress());
        existingBidder.setIfscCode(bidder.getIfscCode());
        return bidderService.updateBidder(bidderId, existingBidder);
    }

    @DeleteMapping("/{bidderId}")
    public void deleteBidderById(@PathVariable Long bidderId) {
        bidderService.deleteBidderById(bidderId);
    }
}