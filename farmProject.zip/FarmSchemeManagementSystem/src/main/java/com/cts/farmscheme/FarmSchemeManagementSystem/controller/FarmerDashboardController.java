package com.cts.farmscheme.FarmSchemeManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bid;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.FarmerDashboardService;

@RestController
@RequestMapping("/farmerDashboard")
public class FarmerDashboardController {
	
	@Autowired
	private FarmerDashboardService farmerDashboardService;
	
	@GetMapping("/{farmerId}/crops")
	public List<Crop> getCropsSummary(@PathVariable("farmerId") Long farmerId){
		return farmerDashboardService.getCropsSummary(farmerId);
	}
	@GetMapping("/{farmerId}/earnings")
	public double getTotalEarnings(@PathVariable Long farmerId) {
		return farmerDashboardService.getTotalEarnings(farmerId);
	}
	@GetMapping("/{farmerId}/activeBids")
	public List<Bid> getActiveBids(@PathVariable Long farmerId){
		return farmerDashboardService.getActiveBids(farmerId);
	}
	@GetMapping("/{farmerId}/notfications")
	public List<String> getNotifications(@PathVariable Long farmerId){
		return farmerDashboardService.getNotifications(farmerId);
	}
	@GetMapping("/{farmerId}/cropStatistics")
	public String getCropStatistics(@PathVariable Long farmerId) {
		return farmerDashboardService.getCropStatistics(farmerId);
	}
}
