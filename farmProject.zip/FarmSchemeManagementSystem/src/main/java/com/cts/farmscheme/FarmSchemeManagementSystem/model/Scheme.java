package com.cts.farmscheme.FarmSchemeManagementSystem.model;

public class Scheme {
	private long schemeId;
	private String schemeName;
	private String description;
	private String eligibityCriteria;
	private String benefits;
	private String applicationStartDate;
	private String applicationEndDate;
	private String documentsRequired;
	private String status;
	public long getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(long schemeId) {
		this.schemeId = schemeId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEligibityCriteria() {
		return eligibityCriteria;
	}
	public void setEligibityCriteria(String eligibityCriteria) {
		this.eligibityCriteria = eligibityCriteria;
	}
	public String getBenefits() {
		return benefits;
	}
	public void setBenefits(String benefits) {
		this.benefits = benefits;
	}
	public String getApplicationStartDate() {
		return applicationStartDate;
	}
	public void setApplicationStartDate(String applicationStartDate) {
		this.applicationStartDate = applicationStartDate;
	}
	public String getApplicationEndDate() {
		return applicationEndDate;
	}
	public void setApplicationEndDate(String applicationEndDate) {
		this.applicationEndDate = applicationEndDate;
	}
	public String getDocumentsRequired() {
		return documentsRequired;
	}
	public void setDocumentsRequired(String documentsRequired) {
		this.documentsRequired = documentsRequired;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
