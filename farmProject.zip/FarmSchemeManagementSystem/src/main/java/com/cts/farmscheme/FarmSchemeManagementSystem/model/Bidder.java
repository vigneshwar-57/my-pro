package com.cts.farmscheme.FarmSchemeManagementSystem.model;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Entity
@Builder
public class Bidder {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bidder_seq")
    @SequenceGenerator(name = "bidder_seq", sequenceName = "bidder_sequence", allocationSize = 1)
    private Long bidderId;

    @NotNull(message = "Enter full Name")
    private String bidderName;

    @NotNull
    private String emailId;

    @NotNull
    private String address;

    @NotNull
    private String accountNumber;

    @NotNull
    private String password;

    @NotNull
    private String ifscCode;

    @NotNull
    private long aadharNumber;

}