package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bidder;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.BidderRepository;

@Service
public class BidderService {
	
	@Autowired
	CropService cropService;

    @Autowired
    private BidderRepository bidderRepository;

    public Bidder addBidder(Bidder bidder) {
    	return bidderRepository.save(bidder);
    }

    public List<Bidder> getAllBidders() {
        return bidderRepository.findAll();
    }

    public Bidder getBidderById(Long id) {
        return bidderRepository.findById(id).orElseThrow(() -> new RuntimeException("Bidder not found"+id));
    }

    public Bidder updateBidder(Long id, Bidder bidder) {
        Bidder existingBidder = bidderRepository.findById(id).orElseThrow(() -> new RuntimeException("Bidder not found"));
        existingBidder.setBidderName(bidder.getBidderName() != null && !bidder.getBidderName().isEmpty() ? bidder.getBidderName() : existingBidder.getBidderName());
        existingBidder.setPassword(bidder.getPassword() != null && !bidder.getPassword().isEmpty() ? bidder.getPassword() : existingBidder.getPassword());
        existingBidder.setAadharNumber(bidder.getAadharNumber()!= 0 ? bidder.getAadharNumber() : existingBidder.getAadharNumber());
        existingBidder.setAccountNumber(bidder.getAccountNumber() != null && !bidder.getAccountNumber().isEmpty() ? bidder.getAccountNumber() : existingBidder.getAccountNumber());
        existingBidder.setAddress(bidder.getAddress() != null && !bidder.getAddress().isEmpty() ? bidder.getAddress() : existingBidder.getAddress());
        existingBidder.setEmailId(bidder.getEmailId() != null && !bidder.getEmailId().isEmpty() ? bidder.getEmailId() : existingBidder.getEmailId());
        existingBidder.setBidderId(bidder.getBidderId() != 0 ? bidder.getBidderId() : existingBidder.getBidderId());
        return bidderRepository.save(existingBidder);
    }

    public void deleteBidderById(Long id) {
        bidderRepository.deleteById(id);
    }
    public List<Bidder> findBidderByName(@PathVariable String bidderName) {
    	return bidderRepository.findByBidderName(bidderName);
    }
    public Optional<Bidder> findBidderById(@PathVariable Long bidderId) {
    	return bidderRepository.findById(bidderId);
    }

	
}