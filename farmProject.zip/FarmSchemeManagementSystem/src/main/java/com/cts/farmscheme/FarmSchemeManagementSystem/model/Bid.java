package com.cts.farmscheme.FarmSchemeManagementSystem.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotNull;
import lombok.Data;



@Data
@Entity
public class Bid {
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bid_seq")
    @SequenceGenerator(name = "bid_seq", sequenceName = "bid_sequence", allocationSize = 1)
	private Long bidId;
	
	@NotNull
	private double BidAmount;
	
	private LocalDateTime bidTime;
	
	@ManyToOne
	private Crop crop;
	
	@Enumerated(EnumType.STRING)
	private BidStatus bidStatus;
	
	@ManyToOne
	private Bidder bidder;
	
}
