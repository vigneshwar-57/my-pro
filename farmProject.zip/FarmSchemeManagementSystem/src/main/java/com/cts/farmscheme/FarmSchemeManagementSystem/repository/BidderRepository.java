package com.cts.farmscheme.FarmSchemeManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bidder;

@Repository
public interface BidderRepository  extends JpaRepository<Bidder, Long>{

	public List<Bidder> findByBidderName(String bidderName);

}
