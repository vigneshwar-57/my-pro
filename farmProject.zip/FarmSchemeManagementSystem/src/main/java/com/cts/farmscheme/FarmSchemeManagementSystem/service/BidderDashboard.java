package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bid;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.BidStatus;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bidder;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.BidRepository;

public class BidderDashboard {

	@Autowired
	private BidderService bidderService;
	
	@Autowired
	private BidRepository bidRepository;
	
	@Autowired
	
	public Bidder getBidderProfile(Long bidderId) {
		return bidderService.getBidderById(bidderId);
	}
	public List<Bid> getBidsWonByBidder(Long bidderId){
		List<Bid> wonBids=new ArrayList<>();
		List<Bid> allBids=bidRepository.findAll();
		
		for(Bid bid : allBids) {
			if(bid.getBidder().getBidderId().equals(bidderId)  && bid.getBidStatus() == BidStatus.WON ) {
				wonBids.add(bid);
			}
		}
		return wonBids;
	}
	public List<Bid> getAllBidsByBidder(Long bidderId){
		List<Bid> bidderBids=new ArrayList<Bid>();
		List<Bid> allBids=bidRepository.findAll();
		
		for(Bid bid:allBids) {
			if(bid.getBidder().getBidderId().equals(bidderId)) {
				bidderBids.add(bid);
			}
				
		}
		return bidderBids;
	}
	public String getBidAnalytics(Long bidderId) {
		int totalBids=0;
		int totalBidsWon=0;
		double totalValueWon=0;
		
		List<Bid> allBids=bidRepository.findAll();
		
		for(Bid bid : allBids) {
			if(bid.getBidder().getBidderId().equals(bidderId)) {
				totalBids++;
				if(bid.getBidStatus()==BidStatus.WON) {
					totalBidsWon++;
					totalValueWon+=bid.getBidAmount();
				}
			}
		}
		return "Total Bids: "+totalBids+" ,Bids Won: "+totalBidsWon+" , Total Value Won: "+totalValueWon;
	}
	
}
