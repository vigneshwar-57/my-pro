package com.cts.farmscheme.FarmSchemeManagementSystem.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Farmer;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.FarmerService;


@RestController
@RequestMapping("/farmers")
public class FarmerController {  
   
    
    @Autowired
    private FarmerService farmerService;

    @PostMapping
    public Farmer addFarmer(@RequestBody Farmer farmer) {
        return farmerService.saveFarmer(farmer);
    }

    @GetMapping
    public List<Farmer> getAllFarmers() {
        List<Farmer> all = farmerService.getAllFarmers();
        return all;
        
    }

    @GetMapping("/{farmerId}")
    public Farmer getFarmerById(@PathVariable("farmerId") Long farmerId) {
        Farmer farmer = farmerService.getFarmerById(farmerId);
        return farmer;
    }

    @PutMapping("/{farmerId}")
    public Farmer updateFarmer(@PathVariable Long farmerId, @RequestBody Farmer farmerDetails) {
        return farmerService.updateFarmer(farmerId, farmerDetails);
       
    }
    @DeleteMapping("/{farmerId}")
    public void deleteFarmer(@PathVariable Long farmerId) {
         farmerService.deleteFarmer(farmerId);
        
    }    
    @PostMapping("/{farmerId}/crops")
    public Farmer addCropToFarmer(@PathVariable Long farmerId,@RequestBody Crop crop) {
    	 return farmerService.addCroptoFarmer(farmerId,crop);
    	
    }
    @GetMapping("/{farmerId}/crops")
    public List<Crop> getCropsByFarmerId(@PathVariable Long farmerId){
    	return farmerService.getCropsByFarmer(farmerId);
    }
    
    @GetMapping("/search-name/{farmerName}")
    public List<Farmer> findFarmersByName(@PathVariable("farmerName") String farmerName){
    	return farmerService.findFarmerByName(farmerName);
    }
    
   
}
