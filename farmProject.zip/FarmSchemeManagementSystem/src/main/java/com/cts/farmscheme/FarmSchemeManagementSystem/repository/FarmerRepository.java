package com.cts.farmscheme.FarmSchemeManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Farmer;

@Repository
public interface FarmerRepository extends JpaRepository<Farmer,Long> {
	List<Farmer>findByName(String name);
}
