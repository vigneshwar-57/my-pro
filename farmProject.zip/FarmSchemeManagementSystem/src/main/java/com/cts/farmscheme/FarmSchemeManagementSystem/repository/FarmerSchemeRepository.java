package com.cts.farmscheme.FarmSchemeManagementSystem.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.FarmerScheme;

public interface FarmerSchemeRepository extends JpaRepository<FarmerScheme, Long> {

	List<FarmerScheme> findByFarmerId(Long farmerId);

}
