package com.cts.farmscheme.FarmSchemeManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmSchemeManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmSchemeManagementSystemApplication.class, args);
		System.out.println("hello world");
	}

}
