package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bid;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.BidStatus;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;

@Service
public class FarmerDashboardService {

	@Autowired
	private FarmerService farmerService;
	
	
	@Autowired
	private BidService bidService;
	
	@Autowired
	private NotificationService notificationService;
	
	public List<Crop> getCropsSummary(Long farmerId){
		List<Crop> crops=farmerService.getCropsByFarmer(farmerId);
		if(crops.isEmpty()) {
			throw new RuntimeException("No crops found for farmer with :"+farmerId);
		}
		return crops;
	}
	public double getTotalEarnings(Long farmerId) {
		List<Crop> crops=farmerService.getCropsByFarmer(farmerId);
		
		double totalEarnings=0.0;
		 
		for(Crop crop:crops) {
			List<Bid> bids=bidService.getBidsByCropId(crop.getCropId());
			for(Bid bid:bids) {
				if(bid.getBidStatus()==BidStatus.WON) {
					totalEarnings+=(crop.getQuantity()*crop.getPricePerUnit());
				}
			}
		}
		return totalEarnings;
	}
	public List<Bid> getActiveBids(Long farmerId){
		List<Crop> crops=farmerService.getCropsByFarmer(farmerId);
		List<Bid> activeBids=new ArrayList<Bid>();
		
		for(Crop crop:crops) {
			List<Bid> bids=bidService.getBidsByCropId(crop.getCropId());
			
			for(Bid bid:bids) {
				if(bid.getBidStatus()==BidStatus.PENDING) {
					activeBids.add(bid);
				}
			}
		}
		return activeBids;
		}
	public String getCropStatistics(Long farmerId) {
		List<Crop> crops=farmerService.getCropsByFarmer(farmerId);
		if(crops.isEmpty()) {
			throw new RuntimeException("No crops found for farmer with ID: "+ farmerId);
		}
		
		Crop mostProfitableCrop=null;
		double highestEarnings=Double.MIN_VALUE;
		
		for(Crop crop:crops) {
			double earnings=crop.getQuantity()*crop.getPricePerUnit();
			
			if(earnings > highestEarnings) {
				highestEarnings=earnings;
				mostProfitableCrop=crop;
			}
		}
		if(mostProfitableCrop!=null) {
			return "Most profitable Crop: "+mostProfitableCrop.getCropName()+" with earnings of "+highestEarnings;
		}
		return "No profitable crops found";
	}
	
	public List<String> getNotifications(Long farmerId){
		return notificationService.getNotificationsForFarmer(farmerId);
	}

	
}
