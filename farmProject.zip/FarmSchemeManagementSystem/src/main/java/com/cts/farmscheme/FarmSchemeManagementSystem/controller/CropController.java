package com.cts.farmscheme.FarmSchemeManagementSystem.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.CropService;

@RestController
@RequestMapping("/crops")
public class CropController {

	@Autowired
	private CropService cropService;

	@PostMapping
	public Crop addCrop(@RequestBody Crop crop) {
		crop.setPlacedDate(LocalDateTime.now());
		return cropService.addCrop(crop);

	}

	@GetMapping
	public List<Crop> getAllCrops() {
		List<Crop> crops = cropService.getAllCrops();
		return crops;

	}

	@GetMapping("/{cropId}")
	public Crop getCropById(@PathVariable Long cropId) {
		return cropService.getCropById(cropId);
	}

	@PutMapping("/{cropId}")
	public Crop updateCrop(@PathVariable Long cropId, @RequestBody Crop cropDetails) {

		Crop existingCrop = cropService.getCropById(cropId);
		if (existingCrop != null) {
			if (cropDetails.getCropName() != null) {
				existingCrop.setCropName(cropDetails.getCropName());
			}
			if (cropDetails.getCropType() != null) {
				existingCrop.setCropType(cropDetails.getCropType());
			}
			if (cropDetails.getPricePerUnit() != null) {
				existingCrop.setPricePerUnit(cropDetails.getPricePerUnit());
			}
			if (cropDetails.getQuantity() != null) {
				existingCrop.setQuantity(cropDetails.getQuantity());
			}
		}

		return cropService.updateCrop(cropId, existingCrop);
	}

	@DeleteMapping("/{cropId}")
	public void deleteCrop(@PathVariable Long cropId) {
		cropService.deleteCrop(cropId);

	}
	@GetMapping("search-id/{cropId}")
	public Optional<Crop> findCropById(@PathVariable("cropId")Long cropId){
		return cropService.findCropById(cropId);
	}
	@GetMapping("search-name/{cropName}")
	public List<Crop> findCropByName(@PathVariable("cropName") String cropName) {
		return cropService.findCropByCropName(cropName);
	}
	 
}