package com.cts.farmscheme.FarmSchemeManagementSystem.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

@Data
@Entity
public class BidderScheme {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "bidderScheme_seq")
	@SequenceGenerator(name="bidderScheme_seq",sequenceName = "bidderScheme_sequence",allocationSize = 1)
	private Long schemeId;
	
	private String schemeName;
	private String insuranceProvider;
	private String coverageAmount;
	
	private LocalDateTime startDate;
	private LocalDateTime endDate;
	
	private String status;
	
	@Column(name="bidder_id")
	private Long bidderId;
}
