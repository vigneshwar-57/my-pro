package com.cts.farmscheme.FarmSchemeManagementSystem.model;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.*;
import lombok.Data;


@Entity
@Data
public class Crop {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "crop_seq")
	@SequenceGenerator(name="crop_seq",sequenceName = "crop_sequence",allocationSize = 1)
    private Long cropId;
 
    private String cropName;
    private String cropType;
    private Long quantity;
    private Double pricePerUnit;
    private LocalDateTime placedDate;
    
    
    @Column(name="farmer_id")
    private Long farmerId;
    
 
}
