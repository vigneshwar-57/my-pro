package com.cts.farmscheme.FarmSchemeManagementSystem.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bid;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.BidService;

@RequestMapping("/bids")
@RestController
public class BidController {
	
	@Autowired
	private BidService bidService;
	
	@PostMapping
	public Bid placeBid(@RequestBody Bid bid ) {
		return bidService.placeBid(bid);
	}
	@GetMapping
	public List<Bid> getAllBids(){
		return bidService.getAllBids();
	}
	@GetMapping("/{bidId}")
	public Optional<Bid> getBidById(@PathVariable("{bidId}") Long bidId) {
		return bidService.findBidById(bidId);
	}
	@PutMapping("/{bidId}")
	public Bid updateBid(@PathVariable Long bidId,@RequestBody Bid updatedBid) {
		Bid existingBid=bidService.findBidById(bidId).orElseThrow(()-> new RuntimeException("No Bid found with: "+bidId));
		existingBid.setBidAmount(updatedBid.getBidAmount());
		existingBid.setBidder(updatedBid.getBidder());
		existingBid.setBidStatus(updatedBid.getBidStatus());
		existingBid.setBidTime(LocalDateTime.now());
		return bidService.updateBid(bidId, updatedBid);
	}
	@DeleteMapping("/{bidId}")
	public void deleteBid(@PathVariable Long bidId) {
		bidService.deleteBid(bidId);
	}
	@PutMapping("/win/bid/crop{cropId}")
	public Bid delcareWinningBid(@PathVariable Long bidId){
		return bidService.winBid(bidId);
	}
}
