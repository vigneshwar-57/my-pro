package com.cts.farmscheme.FarmSchemeManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.BidderScheme;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.FarmerScheme;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.BidderSchemeService;
import com.cts.farmscheme.FarmSchemeManagementSystem.service.FarmerSchemeService;


@RequestMapping("/schemes")
@RestController
public class FarmerBidderSchemeController {
	
	@Autowired
	private FarmerSchemeService farmerSchemeService;
	
	@Autowired
	private BidderSchemeService bidderSchemeService;
	
	@PostMapping("/farmer")
	public FarmerScheme applyFarmerScheme(@RequestBody FarmerScheme farmerScheme) {
		return farmerSchemeService.applyScheme(farmerScheme);
	}
	@GetMapping("/farmer/{farmerId}")
	public List<FarmerScheme> getFarmerSchemes(@PathVariable("farmerId") Long farmerId){
		return farmerSchemeService.getSchemesByFarmerId(farmerId);
	}
	@PostMapping("/bidder")
	public BidderScheme applyBidderScheme(@RequestBody BidderScheme bidderScheme) {
		return bidderSchemeService.applyScheme(bidderScheme);
	}
	@GetMapping("/bidder/{bidderId}")
	public List<BidderScheme> getBidderSchemes(@PathVariable("bidderId") Long bidderId){
		return bidderSchemeService.getSchemesByBidderId(bidderId);
	}
	
	
	
}
