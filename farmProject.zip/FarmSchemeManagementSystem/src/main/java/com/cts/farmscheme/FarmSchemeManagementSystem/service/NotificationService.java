package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {
	
	public List<String> getNotificationsForFarmer(Long farmerId){
		List<String> notifications=new ArrayList<String>();
		
		notifications.add("New Bid placed");
		notifications.add("Your crop A is successfully Sold");
		notifications.add("You have received a new farming scheme ");
		notifications.add("Your crop B is ready for harvest");
		return notifications;
	}
}
