package com.cts.farmscheme.FarmSchemeManagementSystem.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

@Data
@Entity
public class FarmerScheme {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "farmerScheme_seq")
	@SequenceGenerator(name="farmerScheme_seq",sequenceName = "farmerScheme_sequence",allocationSize = 1)
	private Long schemeId;
	
	private String schemeType;
	private double interestRate;
	
	private String status;
	
	private LocalDateTime startDate;
	private LocalDateTime endDate;
	
	private String insuranceCompany;
	
	private String loanProvider;
	
	
	
	@Column(name="farmer_id")
	private Long farmerId;
}
