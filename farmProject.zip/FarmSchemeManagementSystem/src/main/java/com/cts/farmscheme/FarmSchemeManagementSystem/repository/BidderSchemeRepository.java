package com.cts.farmscheme.FarmSchemeManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.BidderScheme;

public interface BidderSchemeRepository extends JpaRepository<BidderScheme, Long> {
		public List<BidderScheme> findByBidderId(Long bidderId);
}
