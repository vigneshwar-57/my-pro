package com.cts.farmscheme.FarmSchemeManagementSystem.model;

public enum BidStatus {
	PENDING,
	WON,
	LOST
}
