package com.cts.farmscheme.FarmSchemeManagementSystem.model;

public class BidderEntity {

}
