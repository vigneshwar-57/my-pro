package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Farmer;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.FarmerRepository;

@Service
public class FarmerService {
	
	@Autowired
	private FarmerRepository farmerRepository;
	
	
	public Farmer saveFarmer(Farmer farmer) {
		Farmer savedFarmer = farmerRepository.save(farmer);
        List<Crop> crops = savedFarmer.getCrops();
        for (Crop crop : crops) {
        	crop.setPlacedDate(LocalDateTime.now());
            crop.setFarmerId(savedFarmer.getFarmerId());
        }
        savedFarmer.setCrops(crops);
        return farmerRepository.save(savedFarmer);
        //return farmerRepository.save(farmer);
	}
	
	public Farmer updateFarmer(Long farmerId, Farmer farmer) {
		    Farmer existingFarmer = farmerRepository.findById(farmerId)
		            .orElseThrow(() -> new RuntimeException("Farmer not found with id: " + farmerId));
		    existingFarmer.setName(farmer.getName() != null && !farmer.getName().isEmpty() ? farmer.getName() : existingFarmer.getName());
		    existingFarmer.setPhoneNumber(farmer.getPhoneNumber() != 0 ? farmer.getPhoneNumber() : existingFarmer.getPhoneNumber());
		    existingFarmer.setPassword(farmer.getPassword() != null && !farmer.getPassword().isEmpty() ? farmer.getPassword() : existingFarmer.getPassword());
		    existingFarmer.setIfscCode(farmer.getIfscCode() != null && !farmer.getIfscCode().isEmpty() ? farmer.getIfscCode() : existingFarmer.getIfscCode());
		    existingFarmer.setEmail(farmer.getEmail() != null && !farmer.getEmail().isEmpty() ? farmer.getEmail() : existingFarmer.getEmail());
		    existingFarmer.setCrops(farmer.getCrops() != null && !farmer.getCrops().isEmpty() ? farmer.getCrops() : existingFarmer.getCrops());
		    existingFarmer.setAddress(farmer.getAddress() != null && !farmer.getAddress().isEmpty() ? farmer.getAddress() : existingFarmer.getAddress());
		    existingFarmer.setAccountNumber(farmer.getAccountNumber() != null && !farmer.getAccountNumber().isEmpty() ? farmer.getAccountNumber() : existingFarmer.getAccountNumber());
		    existingFarmer.setAadharCard(farmer.getAadharCard() != 0 ? farmer.getAadharCard() : existingFarmer.getAadharCard());
		    return farmerRepository.save(existingFarmer);
		}
	public List<Farmer> getAllFarmers(){
		return farmerRepository.findAll();
	}
	public Farmer getFarmerById(Long farmerId){
		return farmerRepository.findById(farmerId).orElseThrow(()-> new RuntimeException("Farmer not found with id"+farmerId));
	}
	public boolean deleteFarmer(Long farmerId) {
		 Farmer farmer=farmerRepository.findById(farmerId).orElseThrow(()-> new RuntimeException("Farmer not found with id: "+farmerId));
		 farmerRepository.delete(farmer);
		 return true;	
	}
	public Farmer addCroptoFarmer(Long farmerId, Crop crop) {
		Farmer farmer=farmerRepository.findById(farmerId).orElseThrow(()-> new RuntimeException("Farmer not found with id: "+farmerId));
		crop.setPlacedDate(LocalDateTime.now());
		farmer.getCrops().add(crop);
		return farmerRepository.save(farmer);
	}
	public List<Crop> getCropsByFarmer(Long farmerId){
		Farmer farmer=farmerRepository.findById(farmerId).orElseThrow(()-> new RuntimeException("Farmer not found with id: "+farmerId));
		return farmer.getCrops();
	}
	public List<Farmer> findFarmerByName(String name){
		return farmerRepository.findByName(name);
	}
	public Optional<Farmer> findFarmerById(Long id){
		return farmerRepository.findById(id);
	}
	
}
