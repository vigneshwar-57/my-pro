package com.cts.farmscheme.FarmSchemeManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bid;

public interface BidRepository extends JpaRepository<Bid,Long>{
	
	public List<Bid> findByCropCropId(Long cropId);
}
