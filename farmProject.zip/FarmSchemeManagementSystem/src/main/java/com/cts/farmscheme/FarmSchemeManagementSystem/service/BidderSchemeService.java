package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.BidderScheme;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.BidderSchemeRepository;

@Service
public class BidderSchemeService {
		
	@Autowired
	private BidderSchemeRepository bidderSchemeRepository;
	
	public BidderScheme applyScheme(BidderScheme bidderScheme) {
		bidderScheme.setStartDate(LocalDateTime.now());
		bidderScheme.setEndDate(LocalDateTime.now().plusYears(1));
		bidderScheme.setStatus("PENDING");
		return bidderSchemeRepository.save(bidderScheme);
		
	
	}
	public List<BidderScheme> getSchemesByBidderId(Long bidderId){
		return bidderSchemeRepository.findByBidderId(bidderId);
	}
	public BidderScheme updateSchemeStatus(Long schemeId,String status) {
		BidderScheme scheme=bidderSchemeRepository.findById(schemeId).orElseThrow(()-> new RuntimeException("Scheme not found"));
		scheme.setStatus(status);
		return bidderSchemeRepository.save(scheme);
	}
}
