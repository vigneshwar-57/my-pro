package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.FarmerScheme;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.FarmerSchemeRepository;


@Service
public class FarmerSchemeService {

	@Autowired
	private FarmerSchemeRepository farmerSchemeRepository;
	
	
	
	public FarmerScheme applyScheme(FarmerScheme farmerScheme) {
		farmerScheme.setStartDate(LocalDateTime.now());
		farmerScheme.setStatus("PENDING");
		
		if(("LOAN ASSISTANCE").equals(farmerScheme.getSchemeType())) {
			farmerScheme.setEndDate(LocalDateTime.now().plusYears(2));
		}
		else if(("CROP INSURANCE").equals(farmerScheme.getSchemeType())){
			farmerScheme.setEndDate(LocalDateTime.now().plusYears(1));
		}
		return farmerSchemeRepository.save(farmerScheme);
	}
	public List<FarmerScheme> getSchemesByFarmerId(Long farmerId){
		return farmerSchemeRepository.findByFarmerId(farmerId);
	}
	public FarmerScheme updateSchemeStatus(Long schemeId, String status) {
		FarmerScheme scheme=farmerSchemeRepository.findById(schemeId).orElseThrow(()-> new RuntimeException("Schemes not found"));
		
		scheme.setStatus(status);
		return farmerSchemeRepository.save(scheme);
	}
	
}
