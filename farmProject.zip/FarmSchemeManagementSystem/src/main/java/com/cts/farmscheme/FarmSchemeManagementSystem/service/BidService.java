package com.cts.farmscheme.FarmSchemeManagementSystem.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bid;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.BidStatus;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Bidder;
import com.cts.farmscheme.FarmSchemeManagementSystem.model.Crop;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.BidRepository;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.BidderRepository;
import com.cts.farmscheme.FarmSchemeManagementSystem.repository.CropRepository;

@Service
public class BidService {

	@Autowired
	private BidRepository bidRepository;

	@Autowired
	private CropRepository cropRepository;

	@Autowired
	private BidderRepository bidderRepository;

	public Bid placeBid(Bid bid) {
		Crop crop = cropRepository.findById(bid.getCrop().getCropId())
				.orElseThrow(() -> new RuntimeException("Crop not found "));
		Bidder bidder = bidderRepository.findById(bid.getBidder().getBidderId())
				.orElseThrow(() -> new RuntimeException("Bidder not found"));
		bid.setCrop(crop);
		bid.setBidder(bidder);
		bid.setBidAmount(bid.getBidAmount());
		bid.setBidTime(LocalDateTime.now());
		bid.setBidStatus(BidStatus.PENDING);
		return bidRepository.save(bid);
	}

	public List<Bid> getAllBids() {
		return bidRepository.findAll();
	}

	public Optional<Bid> findBidById(Long bidId) {
		return bidRepository.findById(bidId);
	}
	public List<Bid> getBidsByCropId(Long cropId){
		return bidRepository.findByCropCropId(cropId);
	}

	public Bid updateBid(Long bidId, Bid updatedBid) {
		Bid existingBid = bidRepository.findById(bidId)
				.orElseThrow(() -> new RuntimeException("Bid not found with:" + bidId));
		existingBid.setBidStatus(updatedBid.getBidStatus());
		existingBid.setBidAmount(updatedBid.getBidAmount());
		existingBid.setBidTime(LocalDateTime.now());
		existingBid.setBidder(updatedBid.getBidder());
		return bidRepository.save(existingBid);
	}

	public void deleteBid(Long bidId) {
		Bid bid = bidRepository.findById(bidId)
				.orElseThrow(() -> new RuntimeException("Bid not found with id" + bidId));
		bidRepository.delete(bid);
	}

	public Bid winBid(Long cropId) {
		List<Bid> bids = bidRepository.findByCropCropId(cropId);
		if (bids.isEmpty()) {
			throw new RuntimeException("No  bids found for the crop");
		}
		Bid winningBid = null;
		double highestAmount = Double.MIN_VALUE;

		for (Bid bid : bids) {
			if (bid.getBidAmount() > highestAmount) {
				highestAmount = bid.getBidAmount();
				winningBid = bid;
			} else if (bid.getBidAmount() == highestAmount) {
				if (winningBid == null || bid.getBidTime().isBefore(winningBid.getBidTime()))
					winningBid = bid;
			}
		}

		for (Bid bid : bids) {
			if (bid.equals(winningBid)) {
				bid.setBidStatus(BidStatus.WON);
			} else {
				bid.setBidStatus(BidStatus.LOST);
			}
			bid.setBidTime(LocalDateTime.now());
			bidRepository.save(bid);
		}
		return winningBid;

	}

}
