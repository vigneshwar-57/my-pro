package com.cts.Farm_Connect_Application.service;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Farm_Connect_Application.model.Crop;
import com.cts.Farm_Connect_Application.model.Farmer;
import com.cts.Farm_Connect_Application.repository.FarmerRepository;

@Service
public class FarmerService {

	@Autowired
	private FarmerRepository farmerRepository;

	public Farmer fetchFarmerByEmail(String email) {
		return farmerRepository.findByEmail(email);
	}
	
	public Farmer saveFarmer(Farmer farmer) {
		return farmerRepository.save(farmer);
	}

	public Farmer validateFarmer(String email, String password) {
		return farmerRepository.findByEmailAndPassword(email, password);
	}

	public void updateFarmer(Farmer farmer, Long farmerId) {
		Farmer existingFarmer = farmerRepository.findById(farmerId).orElseThrow(()-> new RuntimeException("No farmer found with:"));
		existingFarmer.setName(
				farmer.getName() != null && !farmer.getName().isEmpty() ? farmer.getName() : existingFarmer.getName());
		existingFarmer.setPhoneNumber(
				farmer.getPhoneNumber() != 0 ? farmer.getPhoneNumber() : existingFarmer.getPhoneNumber());
		existingFarmer
				.setPassword(farmer.getPassword() != null && !farmer.getPassword().isEmpty() ? farmer.getPassword()
						: existingFarmer.getPassword());
		existingFarmer
				.setIfscCode(farmer.getIfscCode() != null && !farmer.getIfscCode().isEmpty() ? farmer.getIfscCode()
						: existingFarmer.getIfscCode());
		
		existingFarmer.setCrops(farmer.getCrops() != null && !farmer.getCrops().isEmpty() ? farmer.getCrops()
				: existingFarmer.getCrops());
		existingFarmer.setAddress(farmer.getAddress() != null && !farmer.getAddress().isEmpty() ? farmer.getAddress()
				: existingFarmer.getAddress());
		existingFarmer.setAccountNumber(
				farmer.getAccountNumber() != null && !farmer.getAccountNumber().isEmpty() ? farmer.getAccountNumber()
						: existingFarmer.getAccountNumber());
		existingFarmer
				.setAadharCard(farmer.getAadharCard() != 0 ? farmer.getAadharCard() : existingFarmer.getAadharCard());
		 farmerRepository.save(existingFarmer);
	}
	
	public List<Crop> getCropsByFarmer(Long farmerId){
		Farmer farmer=farmerRepository.findById(farmerId).orElseThrow(()-> new RuntimeException("Farmer not found with id: "+farmerId));
		return farmer.getCrops();
	}
	
	
}
