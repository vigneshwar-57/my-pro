package com.cts.Farm_Connect_Application.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.SequenceGenerator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bid {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bid_seq")
	@SequenceGenerator(name = "bid_seq", sequenceName = "bid_sequence", allocationSize = 1)
	private Long bidId;

	@Column(nullable = false)
	private String farmerName;
	
	@Column(nullable = false)
	private String cropName;
	
	@Column(nullable = false)
	private String cropType;
	
	@Column(nullable = false)
	private Long quantity;
	
	@Column(nullable = false)
	private Long basePrice;
	
	@Column(nullable = false)
	private LocalDate cropPlacedDate;
	
	@Column(nullable = false)
	private LocalDate bidPlacedDate;
	
	@Column(nullable = false)
	private String bidStatus;
	
	@PrePersist
	public void setBidStatus() {
		if(this.bidStatus == null) {
			this.bidStatus = "Pending";
		}
	}
	
	@Column(nullable = false)
	private Long biddedAmount;

	@Column(name = "crop_id")
	private Long cropId;


	@Column(name = "bidder_id")
	private Long bidderId;
	
	@Column(name = "farmer_id")
	private Long farmerId;

}
