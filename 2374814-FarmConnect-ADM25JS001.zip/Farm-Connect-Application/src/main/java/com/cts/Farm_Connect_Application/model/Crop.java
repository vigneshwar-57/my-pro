package com.cts.Farm_Connect_Application.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Crop {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crop_seq")
	@SequenceGenerator(name = "crop_seq", sequenceName = "crop_sequence", allocationSize = 1)
	private Long cropId;

	private String cropName;
	private String cropType;

	// quantity in kgs
	private Long quantity;

	private Long basePrice;

	private LocalDate placedDate;

	private String status;

	public void setStatus() {
		if (this.status == null) {
			this.status = "Available";
		}
	}

	private String grade;

	@Column(name = "farmer_id")
	private Long farmerId;
	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="crop_id")
	private List<Bid> bids = new ArrayList<>();

	
}
