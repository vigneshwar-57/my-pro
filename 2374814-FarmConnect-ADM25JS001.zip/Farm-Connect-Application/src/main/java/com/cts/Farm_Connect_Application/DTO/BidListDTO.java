package com.cts.Farm_Connect_Application.DTO;

import java.util.List;

import com.cts.Farm_Connect_Application.model.Bid;

import lombok.Data;

@Data
public class BidListDTO {
	List<Bid> bids;
}
