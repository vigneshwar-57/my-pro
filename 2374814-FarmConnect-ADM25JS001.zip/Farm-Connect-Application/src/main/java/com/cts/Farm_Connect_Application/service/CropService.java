package com.cts.Farm_Connect_Application.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Farm_Connect_Application.model.Crop;
import com.cts.Farm_Connect_Application.model.Farmer;
import com.cts.Farm_Connect_Application.repository.CropRepository;


@Service
public class CropService {
	
	@Autowired
	private CropRepository cropRepository;
	
	public Crop placeCrops(Farmer loggedFarmer,Crop crop) {
		//crop.setPlacedDate(LocalDate.now());
		crop.setStatus("available");
		crop.setFarmerId(loggedFarmer.getFarmerId());
		return cropRepository.save(crop);
	}
	public Crop updateCrop(Long cropId, Crop cropDetails) {
        Crop crop = cropRepository.findById(cropId).orElseThrow(() -> new RuntimeException("Crop not found with id: " + cropId));
        cropDetails.setCropId(cropId);
        cropDetails.setStatus(crop.getStatus());
        return cropRepository.save(cropDetails);
    }
	
	public List<Crop> showAllCropsByFarmerId(Long farmerId) {
		return cropRepository.findByFarmerId(farmerId);
	}
	public List<Crop> showAllCrops() {
		return cropRepository.findAll();
	}
	public boolean deleteCrop(Long cropId) {
        Crop crop = cropRepository.findById(cropId).orElseThrow(() -> new RuntimeException("Crop not found with id: " + cropId));
        cropRepository.delete(crop);
        return true;
    }
	
	public void deleteCropById(Long id) {
        cropRepository.deleteById(id);
    }
	
	public Crop getCropById(Long cropId) {
		return cropRepository.findById(cropId).orElseThrow(() -> new RuntimeException("Crop not found with id: " + cropId));
	}
	
	public List<Object[]> getAllCrops() {
		return cropRepository.findAvailableCrops();
	}
	
	public List<Crop> findSoldCropsByFarmerId(Long farmerId) {
        return cropRepository.findByFarmerIdAndStatus(farmerId, "Sold");
    }
}

