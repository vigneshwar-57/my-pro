package com.cts.Farm_Connect_Application.controller;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cts.Farm_Connect_Application.model.Crop;
import com.cts.Farm_Connect_Application.model.Farmer;

import com.cts.Farm_Connect_Application.service.FarmerService;

import jakarta.servlet.http.HttpSession;

@Controller
public class FarmerController {
	
	@Autowired
	private FarmerService farmerService;
	
	
	@GetMapping("/farmer-dashboard")
	public String getDashboard(HttpSession session, Model model) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:farmer-login";
		}
		List<Crop> registeredCrops=farmerService.getCropsByFarmer(loggedFarmer.getFarmerId());
		model.addAttribute("registeredCrops",registeredCrops);
		model.addAttribute("farmerName",loggedFarmer.getName());
		model.addAttribute("loggedFarmer",loggedFarmer);
		return "FarmerDashboard";
	}
	
	@GetMapping("/farmer-profile")
	public String getFarmerProfile(HttpSession session, Model model) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:farmer-login";
		}
		
		model.addAttribute("loggedFarmerName",loggedFarmer.getName());
		model.addAttribute("farmer",loggedFarmer);
		model.addAttribute("editMode", false);
		return "FarmerProfile";
	}
	
	@PostMapping("/farmer-update")
	public String UpdateFarmerDetails(@ModelAttribute("farmer") Farmer farmer,HttpSession session, Model model, RedirectAttributes attributes) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:farmer-login";
		}
		farmer.setFarmerId(loggedFarmer.getFarmerId());
		farmerService.updateFarmer(farmer,loggedFarmer.getFarmerId());
		model.addAttribute("Profile updated successfully");
		session.setAttribute("loggedFarmer", farmer);
		model.addAttribute("loggedFarmerName",loggedFarmer.getName());
		model.addAttribute("loggedFarmer", loggedFarmer);
		attributes.addFlashAttribute("editMode", false);
		
		return "redirect:/farmer-profile";
	}
	
	@GetMapping("/editProfileForm")
	public String showEditFarmerForm(HttpSession session, Model model) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:/farmer-login";
		}
		model.addAttribute("loggedFarmerName",loggedFarmer.getName());
		model.addAttribute("farmer", loggedFarmer);
		model.addAttribute("editMode", true);
		
		return "FarmerProfile";
	}
	
	
}
