package com.cts.Farm_Connect_Application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.Farm_Connect_Application.model.Bid;

@Repository
public interface BidRepository extends JpaRepository<Bid, Long>{

	@Query("SELECT b FROM Bid b WHERE b.cropId = :cropId")
	Bid findLastBidByCropId(@Param("cropId") Long cropId);
	

	List<Bid> findByCropId(Long cropId);
	
	@Query("SELECT b FROM Bid b WHERE b.cropId = :cropId AND b.bidderId = :bidderId")
	Bid findByCropIdAndBidderId(@Param("cropId") Long cropId, @Param("bidderId") Long bidderId);
	

    List<Bid> findByBidderIdAndBidStatus(Long bidderId, String bidStatus);
}
