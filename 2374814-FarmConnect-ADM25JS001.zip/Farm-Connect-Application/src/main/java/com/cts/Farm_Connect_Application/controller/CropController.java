package com.cts.Farm_Connect_Application.controller;

import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cts.Farm_Connect_Application.model.Bid;
import com.cts.Farm_Connect_Application.model.Crop;
import com.cts.Farm_Connect_Application.model.Farmer;
import com.cts.Farm_Connect_Application.service.BidService;
import com.cts.Farm_Connect_Application.service.CropService;

import jakarta.servlet.http.HttpSession;

@Controller
public class CropController {
	
	@Autowired
	private CropService cropService;
	
	@Autowired
	BidService bidService;
	
	
	@GetMapping("/crop-updateCrop")
	public String UpdateCrop(HttpSession session, Model model) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:farmer-login";
		}
		model.addAttribute("crop",new Crop());
		List<Crop> cropsList = cropService.showAllCropsByFarmerId(loggedFarmer.getFarmerId());

		System.out.println(cropsList.get(0).getBids());
		model.addAttribute("crops", cropsList);
		model.addAttribute("editModeNo", true);
		model.addAttribute("editMode", false);
		model.addAttribute("cropEditMode", false);
		model.addAttribute("loggedFarmer",loggedFarmer.getName());
		return "UpdateCrop";
	}
	
	@GetMapping("/farmer-registerCrop")
	public String showCropRegisterForm(HttpSession session, Model model) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:farmer-login";
		}
		model.addAttribute("crop",new Crop());
		model.addAttribute("loggedFarmerName",loggedFarmer.getName());
		model.addAttribute("editMode", true);
		model.addAttribute("editModeNo", false);
		model.addAttribute("cropEditMode", false);
		return "UpdateCrop";
	}
	
	@PostMapping("/farmer-saveCrop")
	public String saveCrop( @ModelAttribute("crop") Crop crop, HttpSession session, Model model, RedirectAttributes redirectAttributes ) {
		Farmer loggedFarmer=(Farmer) session.getAttribute("loggedFarmer");
		if(loggedFarmer==null) {
			return "redirect:farmer-login";
		}
		model.addAttribute("loggedFarmerName",loggedFarmer.getName());
		crop.setFarmerId(loggedFarmer.getFarmerId());
		cropService.placeCrops(loggedFarmer,crop);
		redirectAttributes.addFlashAttribute("successMessage", "Crop placed successfully");
		return "redirect:/crop-updateCrop";
	}
	
	@GetMapping("/crop-updateDetails/{cropId}")
	public String editCropDetails(@PathVariable("cropId") Long cropId, HttpSession session, Model model) {
	    Farmer loggedFarmer = (Farmer) session.getAttribute("loggedFarmer");
	    if (loggedFarmer == null) {
	        return "redirect:/farmer-login";
	    }
	    
	    // Fetch the crop details using the cropId
	    Crop crop = cropService.getCropById(cropId);
	    if (crop == null) {
	        return "redirect:/crop-list"; // Redirect to crop list if crop not found
	    }
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    String formattedDate = crop.getPlacedDate().format(formatter);
	    model.addAttribute("formattedDate", formattedDate);
	    model.addAttribute("cropEditMode", true);
	    model.addAttribute("editModeNo", false);
	    model.addAttribute("editMode", false);
	    model.addAttribute("loggedFarmer", loggedFarmer.getName());
	    model.addAttribute("crop", crop); // Add the crop details to the model
	    
	    return "UpdateCrop";
	}
	
	@PostMapping("/farmer-editCrop")
	public String updateCropDetails(@ModelAttribute("crop") Crop crop, HttpSession session, Model model) {
	    Farmer loggedFarmer = (Farmer) session.getAttribute("loggedFarmer");
	    if (loggedFarmer == null) {
	        return "redirect:/farmer-login";
	    }
	    
	    // Update the crop details
	    crop.setFarmerId(loggedFarmer.getFarmerId());
	    cropService.updateCrop(crop.getCropId(), crop);
	    
	    return "redirect:/crop-updateCrop"; // Redirect to the crop list page after updating
	}

	
	@PostMapping("/deleteCrop/{id}")
    public String deleteCrop(@PathVariable Long id) {
        cropService.deleteCropById(id);
        return "redirect:/crop-updateCrop";
    }
	
	@GetMapping("/crop-bids/{id}")
    public String viewBids(@PathVariable("id") Long cropId, Model model) {
        Crop crop = cropService.getCropById(cropId);
        List<Bid> bids = crop.getBids();
        model.addAttribute("bids", bids);
        model.addAttribute("crop", crop);
        return "view-bids";
    }
	
	@PostMapping("/accept-bid/{id}")
    public String acceptBid(@PathVariable("id") Long bidId) {
        Bid bid = bidService.findBidById(bidId);
        bid.setBidStatus("Accepted");
        Crop crop = cropService.getCropById(bid.getCropId());
        crop.setStatus("Sold");
        bidService.saveBid(bid);
        return "redirect:/crop-updateCrop";
    }
	
	@GetMapping("/viewSoldCrops")
    public String viewSoldCrops(HttpSession session, Model model) {
        Farmer loggedFarmer = (Farmer) session.getAttribute("loggedFarmer");
        if (loggedFarmer == null) {
            return "redirect:/farmer-login";
        }
        Long farmerId = loggedFarmer.getFarmerId();
        List<Crop> soldCrops = cropService.findSoldCropsByFarmerId(farmerId);

        model.addAttribute("soldCrops", soldCrops);
        return "sold-crops";
    }
	
}
