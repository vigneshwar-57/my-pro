package com.cts.Farm_Connect_Application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Farm_Connect_Application.model.Bidder;
import com.cts.Farm_Connect_Application.repository.BidderRepository;


@Service
public class BidderService {
	
	
	@Autowired
	private BidderRepository bidderRepository;

	public Bidder fetchBidderByEmail(String email) {
		return bidderRepository.findByEmail(email);
	}
	
	public Bidder saveBidder(Bidder bidder) {
		return bidderRepository.save(bidder);
	}

	public Bidder validateBidder(String email, String password) {
		return bidderRepository.findByEmailAndPassword(email, password);
	}
	public Bidder updateBidder(Bidder bidder,Long id) {
		Bidder existingBidder = bidderRepository.findById(id)
		        .orElseThrow(() -> new RuntimeException("Bidder not found"));

		    existingBidder.setBidderName(bidder.getBidderName() != null && !bidder.getBidderName().isEmpty() ? bidder.getBidderName() : existingBidder.getBidderName());
		    existingBidder.setPassword(bidder.getPassword() != null && !bidder.getPassword().isEmpty() ? bidder.getPassword() : existingBidder.getPassword());
		    existingBidder.setAadharNumber(bidder.getAadharNumber() != 0 ? bidder.getAadharNumber() : existingBidder.getAadharNumber());
		    existingBidder.setAccountNumber(bidder.getAccountNumber() != null && !bidder.getAccountNumber().isEmpty() ? bidder.getAccountNumber() : existingBidder.getAccountNumber());
		    existingBidder.setAddress(bidder.getAddress() != null && !bidder.getAddress().isEmpty() ? bidder.getAddress() : existingBidder.getAddress());
		    existingBidder.setEmail(bidder.getEmail() != null && !bidder.getEmail().isEmpty() ? bidder.getEmail() : existingBidder.getEmail());

		    // Log the update
		    System.out.println("Updating bidder with ID: " + existingBidder.getBidderId());

		    // Avoid setting bidderId unless necessary
		    if (bidder.getBidderId() != 0) {
		        existingBidder.setBidderId(bidder.getBidderId());
		    }

	        return bidderRepository.save(existingBidder);
	}
}
