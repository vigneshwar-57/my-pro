package com.cts.Farm_Connect_Application.controller;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cts.Farm_Connect_Application.DTO.CropViewDTO;
import com.cts.Farm_Connect_Application.model.Bid;
import com.cts.Farm_Connect_Application.model.Bidder;
import com.cts.Farm_Connect_Application.model.Crop;
import com.cts.Farm_Connect_Application.model.Farmer;
import com.cts.Farm_Connect_Application.repository.BidRepository;
import com.cts.Farm_Connect_Application.repository.CropRepository;
import com.cts.Farm_Connect_Application.repository.FarmerRepository;
import com.cts.Farm_Connect_Application.service.BidService;
import com.cts.Farm_Connect_Application.service.BidderService;
import com.cts.Farm_Connect_Application.service.CropService;

import jakarta.servlet.http.HttpSession;

@Controller
public class BidderController {

	
	
	@Autowired
	private CropService cropService;
	
	@Autowired
	private BidRepository bidRepository;
	
	@Autowired
	private CropRepository cropRepository;
	
	@Autowired
	private FarmerRepository farmerRepository;
	
	@Autowired
	private BidService bidService;
	
	@Autowired
	private BidderService bidderService;
	
	
	@GetMapping("/bidder-dashboard")
	public String getDashboard(HttpSession session, Model model) {
		Bidder loggedBidder=(Bidder) session.getAttribute("loggedBidder");
		if(loggedBidder==null) {
			return "redirect:/bidder-login";
		}
		model.addAttribute("loggedBidder",loggedBidder.getBidderName());
		model.addAttribute("loggedBidder",loggedBidder);
		
		return "BidderDashboard";
	}
	
//	@GetMapping("/placeYourBid")
//	public String placeYourBid(HttpSession session, Model model) {
//		Bidder loggedBidder=(Bidder) session.getAttribute("loggedBidder");
//		if(loggedBidder==null) {
//			return "redirect:/farmer-login";
//		}
//		model.addAttribute("loggedBidder",loggedBidder.getBidderName());
//		List<Object[]> crops = cropService.getAllCrops();
//		System.out.println(crops.size());
//		List<CropViewDTO> cropList = new ArrayList<>(); 
//		for(Object[] crop : crops) {
//			Long cropId = ((Number) crop[0]).longValue();
//			System.out.println("Crop Id : "+cropId);
//			Bid lastBid = bidRepository.findLastBidByCropId(cropId);
//
//			Long lastBidAmount = 0L;
//			LocalDate lastBidDate = null;
//			String lastBidDateString = "No Bids Yet";
//			if (lastBid != null) {
//			    lastBidAmount = (Long) lastBid.getBiddedAmount();
//			    lastBidDate = (LocalDate) lastBid.getBidPlacedDate();
//			    lastBidDateString = lastBidDate.toString();
//			    System.out.println("Crop Id: " + cropId);
//			    System.out.println("Max Bidded Amount: " + lastBidAmount);
//			    System.out.println("Last Bid Placed Date: " + lastBidDate);
//			} else {
//				
//			    System.out.println("No bids found for Crop Id: " + cropId);
//				
//			}
//			
//			System.out.println("biddedAmount : "+ lastBidAmount);
//			System.out.println("lastBiddeddate : " + lastBidDateString);
//			CropViewDTO cropViewDTO = new CropViewDTO(
//					cropId,
//					(String) crop[1],
//					(String) crop[2],
//					(String) crop[3],
//					((Number) crop[4]).longValue(),
//					((Number) crop[5]).longValue(),
//					(LocalDate) crop[6],
//					(String) crop[7],
//					lastBidAmount,
//					lastBidDateString
//					);
//			
//			cropList.add(cropViewDTO);
//		}
//		System.out.println(cropList.size());
//		model.addAttribute("cropList", cropList);
//		model.addAttribute("editMode", true);
//		model.addAttribute("editModeYes", false);
//		return "PlaceYourBid";
//	}
	
	@GetMapping("/placeYourBid")
	public String placeYourBid(HttpSession session, Model model) {
	    Bidder loggedBidder = (Bidder) session.getAttribute("loggedBidder");
	    if (loggedBidder == null) {
	        return "redirect:/farmer-login";
	    }
	    model.addAttribute("loggedBidder", loggedBidder.getBidderName());
	    List<Object[]> crops = cropService.getAllCrops();
	    System.out.println(crops.size());
	    List<CropViewDTO> cropList = new ArrayList<>();
	    for (Object[] crop : crops) {
	        Long cropId = ((Number) crop[0]).longValue();
	        System.out.println("Crop Id : " + cropId);
	        List<Bid> bids = bidRepository.findByCropId(cropId);

	        Long lastBidAmount = 0L;
	        LocalDate lastBidDate = null;
	        String lastBidDateString = "No Bids Yet";
	        if (!bids.isEmpty()) {
	            Bid lastBid = bids.get(bids.size() - 1); // Get the last bid
	            lastBidAmount = lastBid.getBiddedAmount();
	            lastBidDate = lastBid.getBidPlacedDate();
	            lastBidDateString = lastBidDate.toString();
	            System.out.println("Crop Id: " + cropId);
	            System.out.println("Max Bidded Amount: " + lastBidAmount);
	            System.out.println("Last Bid Placed Date: " + lastBidDate);
	        } else {
	            System.out.println("No bids found for Crop Id: " + cropId);
	        }

	        System.out.println("biddedAmount : " + lastBidAmount);
	        System.out.println("lastBiddeddate : " + lastBidDateString);
	        CropViewDTO cropViewDTO = new CropViewDTO(
	                cropId,
	                (String) crop[1],
	                (String) crop[2],
	                (String) crop[3],
	                ((Number) crop[4]).longValue(),
	                ((Number) crop[5]).longValue(),
	                (LocalDate) crop[6],
	                (String) crop[7],
	                lastBidAmount,
	                lastBidDateString
	        );

	        cropList.add(cropViewDTO);
	    }
	    System.out.println(cropList.size());
	    model.addAttribute("cropList", cropList);
	    model.addAttribute("editMode", true);
	    model.addAttribute("editModeYes", false);
	    return "PlaceYourBid";
	}
	
	@GetMapping("/editBiddedForm/{cropId}")
	public String editBidPlaced(@PathVariable("cropId") Long cropId, HttpSession session ,Model model) {
		
		Bidder loggedBidder = (Bidder) session.getAttribute("loggedBidder");
	    if (loggedBidder == null) {
	        return "redirect:/bidder-login";
	    }
	    model.addAttribute("loggedBidder", loggedBidder.getBidderName());
	    
		Crop crop = cropRepository.findByCropId(cropId);
		Farmer farmersCrop = farmerRepository.findById(crop.getFarmerId()).orElse(null);
		
		Bid lastBid = bidRepository.findLastBidByCropId(cropId);

		Long lastBidAmount = 0L;
		LocalDate lastBidDate = null;
		String lastBidDateString = "No Bids Yet";
		if (lastBid != null) {
		    lastBidAmount = (Long) lastBid.getBiddedAmount();
		    lastBidDate = (LocalDate) lastBid.getBidPlacedDate();
		    lastBidDateString = lastBidDate.toString();
		    System.out.println("Crop Id: " + cropId);
		    System.out.println("Max Bidded Amount: " + lastBidAmount);
		    System.out.println("Last Bid Placed Date: " + lastBidDate);
		} else {
			
		    System.out.println("No bids found for Crop Id: " + cropId);
			
		}
		
		CropViewDTO cropViewDTO = new CropViewDTO(
				cropId,
				farmersCrop.getName(),
				crop.getCropName(),
				crop.getCropType(),
				crop.getQuantity(),
				crop.getBasePrice(),
				crop.getPlacedDate(),
				crop.getGrade(),
				lastBidAmount,
				lastBidDateString
				);
		
		model.addAttribute("editModeYes", true);
		model.addAttribute("editMode", false);
		model.addAttribute("bid", new Bid());
		model.addAttribute("cropView", cropViewDTO);
		return "PlaceYourBid";
	}
	
	@PostMapping("/submit-bid")
	public String submitBid(@ModelAttribute("bid") Bid bid, HttpSession session, Model model) {
	    Bidder loggedBidder = (Bidder) session.getAttribute("loggedBidder");
	    if (loggedBidder == null) {
	        return "redirect:/bidder-login";
	    }

	    
	    Bid existingBid = bidRepository.findByCropIdAndBidderId(bid.getCropId(), loggedBidder.getBidderId());
	    if (existingBid != null) {
	        // Update existing bid
	    	
	        existingBid.setBiddedAmount(bid.getBiddedAmount());
	        existingBid.setBidPlacedDate(bid.getBidPlacedDate());
	        bidRepository.save(existingBid);
	    } else {
	        // Save new bid
	    	bid.setBidderId(loggedBidder.getBidderId());
	        bidRepository.save(bid);
	    }
	    

	    // Redirect to the place your bid page
	    model.addAttribute("editModeYes", false);
		model.addAttribute("editMode", true);
	    return "redirect:/placeYourBid";
	}
	
	@GetMapping("/bidder-bids")
    public String viewBids(HttpSession session, Model model) {
        Bidder loggedBidder = (Bidder) session.getAttribute("loggedBidder");
        if (loggedBidder == null) {
            return "redirect:/bidder-login";
        }
        Long bidderId = loggedBidder.getBidderId();
        List<Bid> acceptedBids = bidService.findAcceptedBidsByBidderId(bidderId);
        List<Bid> pendingBids = bidService.findPendingBidsByBidderId(bidderId);

        model.addAttribute("acceptedBids", acceptedBids);
        model.addAttribute("pendingBids", pendingBids);
        return "bid-history";
    }
	@GetMapping("/bidder-showProfile")
	public String getFarmerProfile(HttpSession session, Model model) {
		Bidder loggedBidder=(Bidder) session.getAttribute("loggedBidder");
		if(loggedBidder==null) {
			return "redirect:bidder-login";
		}
		
		model.addAttribute("loggedBidderName",loggedBidder.getBidderName());
		model.addAttribute("bidder",loggedBidder);
		model.addAttribute("editMode", false);
		model.addAttribute("showMode", true);
		return "BidderProfile";
	}
	
	@GetMapping("/editBidderForm")
	public String showEditFarmerForm(HttpSession session, Model model) {
		Bidder loggedBidder=(Bidder) session.getAttribute("loggedBidder");
		if(loggedBidder==null) {
			return "redirect:/bidder-login";
		}
		model.addAttribute("loggedBidderName",loggedBidder.getBidderName());
		model.addAttribute("bidder", loggedBidder);
		model.addAttribute("editMode", true);
		model.addAttribute("showMode", false);
		
		return "BidderProfile";
	}
    @PostMapping("/bidder-update")
    public String updateProfile(@ModelAttribute("bidder") Bidder bidder,HttpSession session,Bidder updatedProfile, Model model) {
    	Bidder loggedBidder=(Bidder) session.getAttribute("loggedBidder");
		if(loggedBidder==null) {
			return "redirect:/bidder-login";
		}
		bidder.setBidderId(loggedBidder.getBidderId());
		bidderService.updateBidder(bidder,loggedBidder.getBidderId());
		session.setAttribute("loggedBidder", bidder);
		model.addAttribute("loggedBidderName",loggedBidder.getBidderName());
		model.addAttribute("loggedBidder", loggedBidder);
		
		return "redirect:/bidder-showProfile";
    }
	    
}


