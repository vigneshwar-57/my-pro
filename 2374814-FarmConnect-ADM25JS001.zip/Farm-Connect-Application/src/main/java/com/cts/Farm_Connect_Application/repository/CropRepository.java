package com.cts.Farm_Connect_Application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.Farm_Connect_Application.model.Crop;

public interface CropRepository extends JpaRepository<Crop, Long> {
	
	@Query("SELECT c.cropId, f.name, c.cropName, c.cropType, c.quantity, c.basePrice, c.placedDate, c.grade FROM Crop c JOIN Farmer f ON c.farmerId = f.farmerId WHERE c.status = 'available' ")
	List<Object[]> findAvailableCrops();
	
	List<Crop> findByFarmerId(Long farmerId);
	
	Crop findByCropId(Long cropId);
    List<Crop> findByFarmerIdAndStatus(Long farmerId, String status);
	
}
