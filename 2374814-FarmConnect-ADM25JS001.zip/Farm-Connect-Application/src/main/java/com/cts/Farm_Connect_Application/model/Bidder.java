package com.cts.Farm_Connect_Application.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Bidder {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bidder_seq")
	@SequenceGenerator(name = "bidder_seq", sequenceName = "bidder_sequence", allocationSize = 1)
	private Long bidderId;

	@NotNull(message = "Enter full Name")
	private String bidderName;

	@NotNull
	private String email;

	@NotNull
	private String address;

	@NotNull
	private Long phoneNumber;

	@NotNull
	private String accountNumber;

	@NotNull
	private String password;

	@NotNull
	private String ifscCode;

	@NotNull
	private long aadharNumber;

	// Bidder can have multiple bids Bidder only bid one specific crop at a time
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "bidder_id")
	private List<Bid> bids = new ArrayList<Bid>();

}