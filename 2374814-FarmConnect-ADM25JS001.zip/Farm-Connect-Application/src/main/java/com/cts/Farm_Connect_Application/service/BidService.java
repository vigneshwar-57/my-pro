package com.cts.Farm_Connect_Application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Farm_Connect_Application.model.Bid;
import com.cts.Farm_Connect_Application.repository.BidRepository;

@Service
public class BidService {
	
	@Autowired
	private BidRepository bidRepository;
	
	public List<Bid> getBidsByCropId(Long cropId){
		return bidRepository.findByCropId(cropId);
	}
	
	public Bid findBidById(long bidId) {
		return bidRepository.findById(bidId).orElseThrow(()-> new RuntimeException("no bid found"));
	}

	public void saveBid(Bid bid) {
		bidRepository.save(bid);
	}
	
	public List<Bid> findAcceptedBidsByBidderId(Long bidderId) {
        return bidRepository.findByBidderIdAndBidStatus(bidderId, "Accepted");
    }

    public List<Bid> findPendingBidsByBidderId(Long bidderId) {
        return bidRepository.findByBidderIdAndBidStatus(bidderId, "Pending");
    }
}
