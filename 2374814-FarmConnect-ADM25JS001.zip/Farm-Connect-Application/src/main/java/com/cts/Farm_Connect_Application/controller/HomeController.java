package com.cts.Farm_Connect_Application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cts.Farm_Connect_Application.model.Bidder;
import com.cts.Farm_Connect_Application.model.Farmer;
import com.cts.Farm_Connect_Application.service.BidderService;
import com.cts.Farm_Connect_Application.service.FarmerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping
public class HomeController {
	
	@Autowired
	private FarmerService farmerService;
	
	@Autowired
	private BidderService bidderService;
	
    @GetMapping("/")
    public String showHomePage(Model model) {
       // model.addAttribute(new Farmer());
        return "HomePage";
    }
    
    @GetMapping("/logout")
    public String logout(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // Invalidate the session
        }
        redirectAttributes.addFlashAttribute("message", "You have been logged out successfully.");
        return "HomePage"; // Redirect to the home page
    }

    @GetMapping("/farmer-login")
    public String farmerLogin( Model model) {
    	model.addAttribute("farmer" ,new Farmer());    	
    	return "FarmerLogin";
    }
    
    @PostMapping("/farmer/login-form")
    public String farmerLoginForm(@ModelAttribute("farmer") Farmer farmer, HttpSession session, Model model) {
    	Farmer loggedFarmer = farmerService.validateFarmer(farmer.getEmail(), farmer.getPassword());
    	if(loggedFarmer != null ) {
    		session.setAttribute("loggedFarmer", loggedFarmer);
    		return "redirect:/farmer-dashboard";
    	}
    	else {
    		model.addAttribute("errorMessage","Invalid email or password");
    		return "FarmerLogin";
    	}
    }
    
    @GetMapping("/farmer-register")
    public String farmerRegister(Model model) {
    	model.addAttribute("farmer",new Farmer());
    	return "FarmerRegister";
    }
    
    @PostMapping("/farmer-register-form")
    public String farmerRegisterForm(@ModelAttribute("farmer") Farmer farmer, Model model) {
    	String currEmail=farmer.getEmail();
    	if(currEmail != null && !currEmail.isEmpty()) {
    		Farmer existingFarmer = farmerService.fetchFarmerByEmail(currEmail);
    		if(existingFarmer != null ) {
    			model.addAttribute("Farmer with Email "+currEmail+" already exists!");
    			return "FarmerRegister";
    		}
    	}
    	farmerService.saveFarmer(farmer);
    	model.addAttribute("SucessMessage","Farmer registered Successfully");
    	return "FarmerLogin";
    }
    
    
    
    @GetMapping("/bidder-login")
    public String bidderLogin(Model model) {
    	model.addAttribute("bidder" ,new Bidder());    	
    	return "BidderLogin";
    }
    
  
    
    @GetMapping("/bidder-register")
    public String bidderRegister(Model model)
    {
    	model.addAttribute("bidder",new Bidder());
    	return "BidderRegister";
    }
    
    @PostMapping("/bidder-registration-form")
    public String bidderRegistrationForm(@ModelAttribute("bidder")Bidder bidder, Model model) {
    	String currEmail=bidder.getEmail();
    	if(currEmail != null && !currEmail.isEmpty()) {
    		Bidder existingBidder = bidderService.fetchBidderByEmail(currEmail);
    		if(existingBidder != null ) {
    			model.addAttribute("Bidder with Email "+currEmail+" already exists!");
    			return "redirect:/bidder-registration-form";
    		}
    	}
    	bidderService.saveBidder(bidder);
    	model.addAttribute("SucessMessage","Farmer registered Successfully");
    	return "redirect:/bidder/login-form";
    	
    }
    @PostMapping("/bidder/login-form")
    public String bidderLoginForm(@ModelAttribute("bidder") Bidder bidder, HttpSession session, Model model) {
    	Bidder loggedBidder = bidderService.validateBidder(bidder.getEmail(), bidder.getPassword());
    	if(loggedBidder != null ) {
    		session.setAttribute("loggedBidder", loggedBidder);
    		return "redirect:/bidder-dashboard";
    	}
    	else {
    		model.addAttribute("errorMessage","Invalid email or password");
    		return "BidderLogin";
    	}
    }
    
}