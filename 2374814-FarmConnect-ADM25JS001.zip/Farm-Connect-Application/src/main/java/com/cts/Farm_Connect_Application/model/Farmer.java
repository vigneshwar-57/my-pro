package com.cts.Farm_Connect_Application.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
public class Farmer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "farmer_seq")
	@SequenceGenerator(name="farmer_seq",sequenceName = "farmer_sequence",allocationSize = 1)
	private Long farmerId;
	
	@NotNull
	private String name;
	
	@Email
	@NotNull
	private String email;
	
	@NotBlank
	private String password;
	
	@NotNull
	private long phoneNumber;
	
	@NotNull
	private String address;
	
	@NotNull
	private String accountNumber;
	
	@NotNull
	private String ifscCode;
	
	@NotNull
	private long aadharCard;
	
	//a farmer can register multiple crops 
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "farmer_id")
	private List<Crop> crops =new ArrayList<>();
	
}
