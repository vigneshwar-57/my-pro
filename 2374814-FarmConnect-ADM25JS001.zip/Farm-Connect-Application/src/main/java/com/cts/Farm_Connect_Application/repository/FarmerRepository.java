package com.cts.Farm_Connect_Application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.Farm_Connect_Application.model.Crop;
import com.cts.Farm_Connect_Application.model.Farmer;

public interface FarmerRepository  extends JpaRepository<Farmer, Long>{
	Farmer findByEmail(String email);
	Farmer findByEmailAndPassword(String email, String password);
}
