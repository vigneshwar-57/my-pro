package com.cts.Farm_Connect_Application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.Farm_Connect_Application.model.Bidder;

public interface BidderRepository extends JpaRepository<Bidder, Long>{
	Bidder findByEmail(String email);
	Bidder findByEmailAndPassword(String email, String password);
}
