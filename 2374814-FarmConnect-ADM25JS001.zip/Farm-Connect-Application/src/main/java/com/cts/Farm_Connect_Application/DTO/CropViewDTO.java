package com.cts.Farm_Connect_Application.DTO;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CropViewDTO {
	
	private Long cropId;

	private String farmerName;
	
	private String cropName;
	
	private String cropType;
	
	private Long quantity;
	
	private Long basePrice;
	
	private LocalDate placedDate;
	
	private String grade;
	
	private Long bidAmount;
	
	private String lastBiddedDate;
}
