package com.cts.Farm_Connect_Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
